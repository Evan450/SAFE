import os
import sys
import json
import time
import hashlib
import argparse
from getpass import getpass
from cryptography.fernet import Fernet

USERS_DIR = os.path.join(os.path.expanduser('~'), '.safe_config', 'users')

def check_tos_acceptance():
    config_dir = os.path.join(os.path.expanduser('~'), '.safe_config')
    tos_file = os.path.join(config_dir, 'tos_accepted')
    if not os.path.exists(tos_file):
        print("You must accept the Terms of Service (TOS) before using SAFE.")
        print("Please run the startup script to accept the TOS.")
        sys.exit(0)

def create_user(username, esd=False):
    user_path = os.path.join(USERS_DIR, username)
    if os.path.exists(user_path):
        print(f"User '{username}' already exists.")
        return
    password = getpass("Set your password: ")
    confirm_password = getpass("Confirm your password: ")
    if password != confirm_password:
        print("Passwords do not match.")
        return
    try:
        lockout_duration = int(input("Set lockout duration in seconds after 3 failed attempts: "))
    except ValueError:
        print("Invalid lockout duration. Please enter an integer value.")
        return
    salt = os.urandom(16)
    password_hash = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000)
    os.makedirs(user_path)
    key = Fernet.generate_key()
    with open(os.path.join(user_path, 'key.key'), 'wb') as key_file:
        key_file.write(key)
    user_info = {
        'salt': salt.hex(),
        'password_hash': password_hash.hex(),
        'failed_attempts': 0,
        'lockout_time': 0,
        'lockout_duration': lockout_duration,
        'esd': esd
    }
    with open(os.path.join(user_path, 'user_info.json'), 'w') as info_file:
        json.dump(user_info, info_file)
    print(f"User '{username}' created successfully.")

def authenticate_user(username):
    user_path = os.path.join(USERS_DIR, username)
    if not os.path.exists(user_path):
        print(f"User '{username}' does not exist.")
        return None
    with open(os.path.join(user_path, 'user_info.json'), 'r') as info_file:
        user_info = json.load(info_file)
    if user_info['lockout_time'] > time.time():
        remaining = int(user_info['lockout_time'] - time.time())
        print(f"Account is locked. Try again in {remaining} seconds.")
        return None
    password = getpass("Enter your password: ")
    salt = bytes.fromhex(user_info['salt'])
    password_hash = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000)
    if password_hash.hex() == user_info['password_hash']:
        user_info['failed_attempts'] = 0
        user_info['lockout_time'] = 0
        with open(os.path.join(user_path, 'user_info.json'), 'w') as info_file:
            json.dump(user_info, info_file)
        key = open(os.path.join(user_path, 'key.key'), 'rb').read()
        return key
    else:
        user_info['failed_attempts'] += 1
        attempts_left = 3 - user_info['failed_attempts']
        if user_info['failed_attempts'] >= 3:
            if user_info.get('esd', False):
                print("Incorrect password entered three times. Initiating ESD...")
                delete_user(username)
                return None
            else:
                user_info['lockout_time'] = time.time() + user_info['lockout_duration']
                print(f"Account locked for {user_info['lockout_duration']} seconds.")
        else:
            warning = "Warning: Three incorrect attempts will result in data loss." if user_info.get('esd', False) else "Warning: Account will be locked after three incorrect attempts."
            print(f"Incorrect password. {attempts_left} attempts left. {warning}")
        with open(os.path.join(user_path, 'user_info.json'), 'w') as info_file:
            json.dump(user_info, info_file)
        return None

def delete_user(username):
    user_path = os.path.join(USERS_DIR, username)
    if os.path.exists(user_path):
        for root, dirs, files in os.walk(user_path, topdown=False):
            for name in files:
                os.remove(os.path.join(root, name))
            for name in dirs:
                os.rmdir(os.path.join(root, name))
        os.rmdir(user_path)
        print(f"User '{username}' and all associated data have been deleted.")

def delete_account(username):
    user_path = os.path.join(USERS_DIR, username)
    if not os.path.exists(user_path):
        print(f"User '{username}' does not exist.")
        return
    password = getpass("Enter your password to confirm account deletion: ")
    salt = bytes.fromhex(load_user_info(username)['salt'])
    password_hash = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000)
    if password_hash.hex() == load_user_info(username)['password_hash']:
        os.remove(os.path.join(user_path, 'key.key'))
        os.remove(os.path.join(user_path, 'user_info.json'))
        os.rmdir(user_path)
        print(f"User '{username}' account has been deleted. Data remains intact.")
    else:
        print("Incorrect password. Account deletion aborted.")

def load_user_info(username):
    user_path = os.path.join(USERS_DIR, username)
    with open(os.path.join(user_path, 'user_info.json'), 'r') as info_file:
        return json.load(info_file)

def find_targets(target_name):
    matches = []
    search_path = 'C:\\' if os.name == 'nt' else '/'
    for root, dirs, files in os.walk(search_path):
        if target_name in files or target_name in dirs:
            full_path = os.path.join(root, target_name)
            matches.append(full_path)
    return matches

def select_target(matches):
    print("Multiple matches found:")
    for idx, match in enumerate(matches):
        print(f"{idx + 1}. {match}")
    try:
        choice = int(input("Enter the number of the target you want to select: "))
        if 1 <= choice <= len(matches):
            return matches[choice - 1]
        else:
            print("Invalid selection.")
            return None
    except ValueError:
        print("Invalid input.")
        return None

def encrypt_target(username, target_name):
    key = authenticate_user(username)
    if key:
        matches = []
        if os.path.exists(target_name):
            matches.append(os.path.abspath(target_name))
        else:
            matches = find_targets(target_name)
        if not matches:
            print(f"No matches found for '{target_name}'.")
            return
        if len(matches) > 1:
            target_path = select_target(matches)
            if not target_path:
                return
        else:
            target_path = matches[0]
        if os.path.isfile(target_path):
            encrypt_file(target_path, key)
        elif os.path.isdir(target_path):
            encrypt_folder(target_path, key)
        else:
            print("Selected target is neither a file nor a folder.")

def decrypt_target(username, target_name):
    key = authenticate_user(username)
    if key:
        matches = []
        if os.path.exists(target_name):
            matches.append(os.path.abspath(target_name))
        else:
            matches = find_targets(target_name)
        if not matches:
            print(f"No matches found for '{target_name}'.")
            return
        if len(matches) > 1:
            target_path = select_target(matches)
            if not target_path:
                return
        else:
            target_path = matches[0]
        if os.path.isfile(target_path):
            decrypt_file(target_path, key)
        elif os.path.isdir(target_path):
            decrypt_folder(target_path, key)
        else:
            print("Selected target is neither a file nor a folder.")

def encrypt_file(file_path, key):
    fernet = Fernet(key)
    try:
        with open(file_path, 'rb') as file:
            original = file.read()
        encrypted = fernet.encrypt(original)
        with open(file_path, 'wb') as encrypted_file:
            encrypted_file.write(encrypted)
        print(f"File '{file_path}' encrypted successfully.")
    except Exception as e:
        print(f"Encryption failed for '{file_path}': {e}")

def decrypt_file(file_path, key):
    fernet = Fernet(key)
    try:
        with open(file_path, 'rb') as enc_file:
            encrypted = enc_file.read()
        decrypted = fernet.decrypt(encrypted)
        with open(file_path, 'wb') as dec_file:
            dec_file.write(decrypted)
        print(f"File '{file_path}' decrypted successfully.")
    except Exception as e:
        print(f"Decryption failed for '{file_path}': {e}")

def encrypt_folder(folder_path, key):
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            file_path = os.path.join(root, file)
            encrypt_file(file_path, key)

def decrypt_folder(folder_path, key):
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            file_path = os.path.join(root, file)
            decrypt_file(file_path, key)

def main():
    check_tos_acceptance()
    parser = argparse.ArgumentParser(description="Secure Access File Encryption (SAFE)")
    parser.add_argument('action', choices=['create-user', 'encrypt', 'decrypt', 'delete-account'], help="Action to perform")
    parser.add_argument('--user', help="Username for the account")
    parser.add_argument('--target', help="File or folder to encrypt/decrypt")
    parser.add_argument('--esd', action='store_true', help="Enable ESD (Emergency Self-Destruct) on the account")
    args = parser.parse_args()

    if not os.path.exists(USERS_DIR):
        os.makedirs(USERS_DIR)

    if args.action == 'create-user':
        if args.user:
            create_user(args.user, esd=args.esd)
        else:
            print("Please specify a username using --user")
    elif args.action == 'encrypt':
        if args.user and args.target:
            encrypt_target(args.user, args.target)
        else:
            print("Please specify the username and target using --user and --target")
    elif args.action == 'decrypt':
        if args.user and args.target:
            decrypt_target(args.user, args.target)
        else:
            print("Please specify the username and target using --user and --target")
    elif args.action == 'delete-account':
        if args.user:
            delete_account(args.user)
        else:
            print("Please specify the username using --user")

if __name__ == '__main__':
    main()