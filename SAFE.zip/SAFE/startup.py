import os
import sys
import shutil
import subprocess

TT = """
TERMS OF SERVICE (TOS)

By using the Secure Access File Encryption (SAFE) program, you agree to the following terms:

1. The developer(s) are not liable or responsible for any misuse of this program.
2. The program is provided 'as is' without any warranties.
3. You agree not to use this program for any illegal activities, including but not limited to encrypting files without proper authorization, decrypting files without proper authorization, and more.
4. The TOS is void if the program is used irresponsibly or as discribed in #3.

Do you accept these terms? (yes/no)
"""

TUT = """
Welcome to the Secure Access File Encryption (SAFE) tutorial!

SAFE allows you to securely encrypt and decrypt your files with password-protected user accounts.

Basic Usage:

1. **Create a New User Account**:
 safe create-user --user your_username [--esd]
- `--user your_username`: Specifies your username.
- `--esd`: (Optional) Enables Emergency Self-Destruct (ESD) on your account.

2. **Encrypt a File or Folder**:
 safe encrypt --user your_username --target filename_or_folder

4. **Delete Your Account**:
 safe delete-account --user your_username

Security Considerations:

- **Passwords**: Use strong, unique passwords for your accounts.
- **ESD**: Be cautious with ESD; it will permanently delete your data after three incorrect password attempts.
- **Backups**: Regularly back up your data and encryption keys securely.

Thank you for choosing SAFE!
"""

def main():
 print(TT)
 accepted = input().strip().lower()
 if accepted != 'yes':
     print("You must accept the TOS to use SAFE.")
     sys.exit(0)

 config_dir = os.path.join(os.path.expanduser('~'), '.safe_config')
 if not os.path.exists(config_dir):
     os.makedirs(config_dir)
 with open(os.path.join(config_dir, 'tos_accepted'), 'w') as f:
     f.write('accepted')

 print(TUT)
 input("Press Enter to continue...")

 users_dir = os.path.join(config_dir, 'users')
 if not os.path.exists(users_dir):
     os.makedirs(users_dir)

 hide_directory(config_dir)

 safe_source = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'safe.py')
 safe_destination = os.path.join(config_dir, 'safe.py')
 shutil.copyfile(safe_source, safe_destination)

 add_to_path(config_dir)

 self_delete()

def hide_directory(path):
 if os.name == 'nt':
     import ctypes
     FILE_ATTRIBUTE_HIDDEN = 0x02
     try:
         ctypes.windll.kernel32.SetFileAttributesW(path, FILE_ATTRIBUTE_HIDDEN)
     except Exception as e:
         print(f"Failed to hide directory: {e}")
 else:
     pass

def add_to_path(safe_dir):
 if os.name == 'nt':
     import winreg
     try:
         key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, 'Environment', 0, winreg.KEY_ALL_ACCESS)
         try:
             path_value, _ = winreg.QueryValueEx(key, 'PATH')
         except FileNotFoundError:
             path_value = ''
         if safe_dir not in path_value:
             new_path = f"{path_value};{safe_dir}"
             winreg.SetValueEx(key, 'PATH', 0, winreg.REG_EXPAND_SZ, new_path)
             print("Added SAFE to system PATH. Please restart your command prompt.")
     except PermissionError:
         print("Permission denied while modifying PATH. Please run as administrator.")
 else:
     shell_profile = os.path.expanduser('~/.bashrc')
     if not os.path.exists(shell_profile):
         shell_profile = os.path.expanduser('~/.bash_profile')
     path_line = f'\nexport PATH="$PATH:{safe_dir}"\n'
     with open(shell_profile, 'a') as f:
         f.write(path_line)
     print("Added SAFE to system PATH. Please restart your terminal session.")

 if os.name == 'nt':
     script_path = os.path.join(safe_dir, 'safe.bat')
     with open(script_path, 'w') as f:
         f.write(f'@echo off\npython "{os.path.join(safe_dir, "safe.py")}" %*')
 else:
     script_path = os.path.join(safe_dir, 'safe')
     with open(script_path, 'w') as f:
         f.write(f'#!/bin/sh\npython "{os.path.join(safe_dir, "safe.py")}" "$@"')
     os.chmod(script_path, 0o755)

def self_delete():
 startup_script = os.path.abspath(__file__)
 try:
     os.remove(startup_script)
     print("Setup complete. The startup script has been removed.")
 except Exception as e:
     print(f"Could not delete the startup script: {e}")

if __name__ == '__main__':
 main()